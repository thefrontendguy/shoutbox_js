import React from 'react';
import ReactDOM from 'react-dom';

import ShoutsApp from './components/ShoutsApp';


ReactDOM.render(<ShoutsApp />,
    document.getElementById('shoutbox'));