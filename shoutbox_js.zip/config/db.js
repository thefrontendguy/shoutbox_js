// use mlab or your local mongo

// mlab
module.exports = 'mongodb://forovos:ovospassword@ds263137.mlab.com:63137/shoutbox';

// local db
//module.exports = 'mongodb://127.0.0.1:27017/shoutbox';